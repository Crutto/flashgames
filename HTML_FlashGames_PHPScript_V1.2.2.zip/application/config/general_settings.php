<?php
defined("BASEPATH") OR exit("No direct script access allowed");
$config["sitename"] = 'Flash Games';
$config["logo"] = '<span>Flash<i class="md md-gamepad"></i>Games</span>';
$config["emailsite"] = "support@coffeetheme.com";
$config["valide_inscrit"] = "1";
$config["maintenance"] = FALSE;
$config["maintenance_message"] = "Maintenance message";
$config["facebook"] = "https://www.facebook.com/coffeetheme/";
$config["twitter"] = "https://twitter.com/coffeetheme";
$config["google"] = "https://plus.google.com/b/113675398586774502189/113675398586774502189";
$config["roms"] = TRUE;
$config["terms"] = "";
?>