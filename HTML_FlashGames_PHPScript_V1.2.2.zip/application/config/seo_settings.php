<?php
defined("BASEPATH") OR exit("No direct script access allowed");
$config["author"] = 'Coffee Theme';
$config["keywords"] = 'Flash game, Script PHP';
$config["description"] = 'Online Flash Games';
$config["home_nb"] = "9";
$config["cat_nb"] = "2";
$config["home_pag"] = "54";
$config["cat_pag"] = "30";
$config["coms_pag"] = "10";
$config["more_pag"] = "40";
$config["google_analytics"] = '<script>
  (function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'https://www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-10447845-86\', \'auto\');
  ga(\'send\', \'pageview\');

</script>';
$config["cache_activation"] = 0;
$config["cache_expire"] = "1";
?>