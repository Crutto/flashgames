<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config["full_tag_open"] = '<ul class="pagination pagination-split">';
$config["full_tag_close"] = '</ul>';
$config["prev_tag_open"] = '<li>';
$config["prev_tag_close"] = '</li>';
$config["next_tag_open"] = '<li>';
$config["next_tag_close"] = '</li>';
$config["num_tag_open"] = '<li>';
$config["num_tag_close"] = '</li>';
$config["cur_tag_open"] = '<li class="active"><a>';
$config["cur_tag_close"] = '</a></li>';
$config["first_link"] = false;
$config["last_link"] = false;
