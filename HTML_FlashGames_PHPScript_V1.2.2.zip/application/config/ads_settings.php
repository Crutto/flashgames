<?php
defined("BASEPATH") OR exit("No direct script access allowed");
$config["sidebartop"] = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Banner demo -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1938129054627089"
     data-ad-slot="8129382331"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';
$config["sidebarbottom"] = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Banner demo -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1938129054627089"
     data-ad-slot="8129382331"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';
$config["sidebarcontent"] = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Banner demo -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-1938129054627089"
     data-ad-slot="8129382331"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';
?>