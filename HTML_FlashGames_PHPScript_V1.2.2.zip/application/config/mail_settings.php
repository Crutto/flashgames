<?php
defined("BASEPATH") OR exit("No direct script access allowed");
$config["titleMailConfirmation"] = 'Titre mail Confirmation inscription';
$config["mailConfirmation"] = 'Please confirm your registration by clicking on the following link :

%url%';
$config["titleMailWelcome"] = 'Welcome';
$config["mailWelcome"] = 'You are welcome !';
$config["titleMailRecovery"] = 'Recovery';
$config["mailRecovery"] = 'Please follow the instructions below to change your password.

%url%';
$config["titleMailPasswordChanged"] = 'Password changed';
$config["mailPasswordChanged"] = 'Your password has been changed';
?>